package com.drogueriejamal.inventory;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
